const $ = (selector) => document.querySelector(selector);
const currency = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 });
const exactCurrency = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', minimumFractionDigits: 2 });
const palette = ['#4da77a','#80bd8e','#75a5a0','#9b9cce','#d9a16b','#d98178','#77a6ca','#91ae6f','#ad8ac2'];
let expenses = [];
let toastTimer;
const todayLocal = () => {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;
};
function setConnection(connected) {
  $('#connection').textContent = connected ? 'MySQL connected' : 'Database unavailable';
  $('.live-dot').style.background = connected ? '#3ab87b' : '#d66565';
}
function showToast(message, error = false) {
  const toast = $('#toast'); toast.textContent = message; toast.classList.toggle('error', error); toast.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove('show'), 2600);
}
async function api(url, options) {
  const response = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...options });
  if (!response.ok) {
    let message = 'Something went wrong.';
    try { message = (await response.json()).error || message; } catch {}
    throw new Error(message);
  }
  return response.status === 204 ? null : response.json();
}
async function refresh() {
  try { expenses = await api('/api/expenses'); setConnection(true); render(); }
  catch (error) { setConnection(false); $('#expenseRows').replaceChildren(); $('#emptyState').classList.add('show'); $('#emptyState').querySelector('strong').textContent = 'Could not load expenses'; $('#emptyState').querySelector('span').textContent = error.message; }
}
function render() {
  const sum = expenses.reduce((acc, row) => acc + Number(row.amount), 0);
  const now = new Date();
  const thisMonth = expenses.filter(row => {
    const d = new Date(`${row.date}T00:00:00`);
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  }).reduce((acc, row) => acc + Number(row.amount), 0);
  $('#totalSpent').textContent = currency.format(sum);
  $('#monthSpent').textContent = currency.format(thisMonth);
  $('#transactionCount').textContent = expenses.length.toLocaleString('en-IN');
  $('#averageSpent').textContent = currency.format(expenses.length ? sum / expenses.length : 0);
  $('#monthCaption').textContent = now.toLocaleDateString('en', { month: 'long', year: 'numeric' });
  $('#rowCount').textContent = `Showing ${expenses.length} transaction${expenses.length === 1 ? '' : 's'}`;
  const body = $('#expenseRows'); body.replaceChildren();
  const rows = expenses.slice(0, 8);
  for (const expense of rows) {
    const tr = document.createElement('tr');
    const description = document.createElement('td'); description.textContent = expense.description;
    const category = document.createElement('td'); const pill = document.createElement('span'); pill.className = 'category-pill'; pill.textContent = expense.category; category.append(pill);
    const date = document.createElement('td'); date.textContent = new Date(`${expense.date}T00:00:00`).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
    const payment = document.createElement('td'); payment.textContent = expense.paymentMethod || 'Other';
    const amount = document.createElement('td'); amount.className = 'align-right amount'; amount.textContent = exactCurrency.format(Number(expense.amount));
    const action = document.createElement('td'); const del = document.createElement('button'); del.className = 'delete-btn'; del.type = 'button'; del.setAttribute('aria-label', `Delete ${expense.description}`); del.title = 'Delete expense'; del.textContent = '×'; del.addEventListener('click', () => removeExpense(expense.id)); action.append(del);
    tr.append(description, category, date, payment, amount, action); body.append(tr);
  }
  $('#emptyState').classList.toggle('show', expenses.length === 0);
  $('#emptyState').querySelector('strong').textContent = 'No expenses yet';
  $('#emptyState').querySelector('span').textContent = 'Add your first expense to see it here.';
  drawCategoryChart(); drawTrendChart();
}
function drawCategoryChart() {
  const totals = new Map();
  for (const expense of expenses) totals.set(expense.category, (totals.get(expense.category) || 0) + Number(expense.amount));
  const entries = [...totals.entries()].sort((a,b) => b[1]-a[1]).slice(0, 6);
  const container = $('#categoryChart'); container.replaceChildren();
  if (!entries.length) { const empty = document.createElement('div'); empty.className='no-chart'; empty.textContent='Add expenses to see category breakdown'; container.append(empty); return; }
  const max = entries[0][1];
  entries.forEach(([name,value],i) => {
    const row = document.createElement('div'); row.className='category-row';
    const label = document.createElement('span'); label.className='category-name'; label.textContent=name;
    const track = document.createElement('div'); track.className='bar-track'; const fill=document.createElement('div'); fill.className='bar-fill'; fill.style.width=`${Math.max(3,value/max*100)}%`; fill.style.background=palette[i%palette.length]; track.append(fill);
    const amount=document.createElement('span'); amount.className='category-value'; amount.textContent=currency.format(value);
    row.append(label,track,amount); container.append(row);
  });
}
function drawTrendChart() {
  const canvas=$('#trendChart'), rect=canvas.getBoundingClientRect(), ratio=window.devicePixelRatio||1;
  canvas.width=Math.max(1,Math.floor(rect.width*ratio)); canvas.height=Math.max(1,Math.floor(rect.height*ratio));
  const ctx=canvas.getContext('2d'); ctx.scale(ratio,ratio);
  const w=rect.width,h=rect.height,left=42,right=8,top=9,bottom=27,plotW=w-left-right,plotH=h-top-bottom;
  const now=new Date(); const months=[];
  for(let i=5;i>=0;i--){const d=new Date(now.getFullYear(),now.getMonth()-i,1);months.push({year:d.getFullYear(),month:d.getMonth(),label:d.toLocaleDateString('en',{month:'short'})});}
  const values=months.map(m=>expenses.filter(e=>{const d=new Date(`${e.date}T00:00:00`);return d.getFullYear()===m.year&&d.getMonth()===m.month;}).reduce((sum,e)=>sum+Number(e.amount),0));
  const max=Math.max(...values,1); const step=max/4;
  ctx.font='10px DM Sans, sans-serif'; ctx.textBaseline='middle';
  for(let i=0;i<=4;i++){
    const y=top+plotH-(i/4)*plotH; ctx.strokeStyle='#edf1ed';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(left,y);ctx.lineTo(w-right,y);ctx.stroke();
    ctx.fillStyle='#a0a89f';const tick=step*i;ctx.textAlign='right';ctx.fillText(tick===0?'0':tick>=1000?`${(tick/1000).toFixed(tick>=10000?0:1)}k`:Math.round(tick),left-9,y);
  }
  const slot=plotW/months.length,barW=Math.min(29,slot*.48);
  months.forEach((m,i)=>{
    const x=left+i*slot+slot/2; const bh=values[i]/max*(plotH-3); const y=top+plotH-bh;
    ctx.fillStyle=i===months.length-1?'#267b53':'#a9d4b6'; roundRect(ctx,x-barW/2,y,barW,Math.max(0,bh),5); ctx.fill();
    ctx.fillStyle='#899288';ctx.textAlign='center';ctx.textBaseline='top';ctx.fillText(m.label,x,h-bottom+9);
  });
}
function roundRect(ctx,x,y,w,h,r){if(h<=0)return;ctx.beginPath();ctx.roundRect(x,y,w,Math.min(h,r*2),[Math.min(r,h/2),Math.min(r,h/2),0,0]);ctx.fill();}
async function removeExpense(id){
  if(!confirm('Delete this expense?'))return;
  try{await api(`/api/expenses/${id}`,{method:'DELETE'});showToast('Expense deleted');await refresh();}
  catch(error){showToast(error.message,true);}
}
const modal=$('#modalBackdrop'),form=$('#expenseForm');
function openModal(){form.reset();form.elements.date.value=todayLocal();$('#formError').textContent='';$('#saveExpense').disabled=false;modal.hidden=false;setTimeout(()=>form.elements.description.focus(),30);}
function closeModal(){modal.hidden=true;}
$('#addExpenseTop').addEventListener('click',openModal);$('#addExpenseBottom').addEventListener('click',openModal);$('#emptyAdd').addEventListener('click',openModal);
$('#closeModal').addEventListener('click',closeModal);$('#cancelModal').addEventListener('click',closeModal);
modal.addEventListener('click',e=>{if(e.target===modal)closeModal();});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!modal.hidden)closeModal();});
form.addEventListener('submit',async e=>{
  e.preventDefault();$('#formError').textContent='';const save=$('#saveExpense');save.disabled=true;save.textContent='Saving…';
  const data=Object.fromEntries(new FormData(form).entries());data.amount=Number(data.amount);
  try{await api('/api/expenses',{method:'POST',body:JSON.stringify(data)});closeModal();showToast('Expense saved to MySQL');await refresh();}
  catch(error){$('#formError').textContent=error.message;}
  finally{save.disabled=false;save.textContent='Save expense';}
});
$('#addExpenseTop').addEventListener('click',()=>{});
window.addEventListener('resize',()=>{if(expenses)drawTrendChart();});
refresh();

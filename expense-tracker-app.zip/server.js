require('dotenv').config();
const express = require('express');
const mysql = require('mysql2/promise');
const path = require('path');
const { init: initExcelize } = require('excelize-wasm');

const app = express();
const port = Number(process.env.PORT || 3000);
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'expense_tracker',
  waitForConnections: true,
  connectionLimit: 10,
  decimalNumbers: true,
  dateStrings: true,
  timezone: 'Z'
});
const excelizePromise = initExcelize(path.join(__dirname, 'node_modules', 'excelize-wasm', 'excelize.wasm.gz'));

app.use(express.json({ limit: '32kb' }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/health', async (_req, res) => {
  try { await pool.query('SELECT 1'); res.json({ ok: true, database: 'connected' }); }
  catch (error) { res.status(503).json({ ok: false, error: 'Cannot connect to MySQL. Check your .env settings and make sure MySQL is running.' }); }
});

app.get('/api/expenses', async (_req, res) => {
  try {
    const [rows] = await pool.execute(
      'SELECT id, DATE_FORMAT(spent_on, "%Y-%m-%d") AS date, description, category, amount, payment_method AS paymentMethod, notes FROM expenses ORDER BY spent_on DESC, id DESC LIMIT 5000'
    );
    res.json(rows);
  } catch (error) {
    console.error('List expenses:', error.message);
    res.status(503).json({ error: 'Could not load expenses. Check the MySQL connection and database setup.' });
  }
});

app.get('/api/export.xlsx', async (_req, res) => {
  try {
    const [rows] = await pool.execute(
      'SELECT DATE_FORMAT(spent_on, "%Y-%m-%d") AS date, description, category, amount, payment_method AS paymentMethod, notes FROM expenses ORDER BY spent_on ASC, id ASC'
    );
    const excelize = await excelizePromise;
    const workbook = excelize.NewFile();
    if (workbook.error) throw new Error(workbook.error);
    const renamed = workbook.SetSheetName('Sheet1', 'Dashboard');
    if (renamed.error) throw new Error(renamed.error);
    const added = workbook.NewSheet('Transactions');
    if (added.error) throw new Error(added.error);
    workbook.SetActiveSheet(0);

    const putRow = (sheet, cell, values) => {
      const result = workbook.SetSheetRow(sheet, cell, values);
      if (result.error) throw new Error(result.error);
    };
    const headerStyle = workbook.NewStyle({
      Font: { Bold: true, Color: 'FFFFFF' },
      Fill: { Type: 'pattern', Pattern: 1, Color: ['1D714F'] }
    });
    const titleStyle = workbook.NewStyle({ Font: { Bold: true, Size: 18, Color: '155B3E' } });
    const moneyStyle = workbook.NewStyle({ CustomNumFmt: '₹#,##0.00;[Red]-₹#,##0.00' });
    for (const style of [headerStyle, titleStyle, moneyStyle]) if (style.error) throw new Error(style.error);
    for (const [sheet, start, end, width] of [
      ['Dashboard', 'A', 'A', 24], ['Dashboard', 'B', 'B', 17],
      ['Dashboard', 'D', 'D', 19], ['Dashboard', 'E', 'E', 17],
      ['Transactions', 'A', 'A', 15], ['Transactions', 'B', 'B', 30],
      ['Transactions', 'C', 'C', 19], ['Transactions', 'D', 'D', 16],
      ['Transactions', 'E', 'E', 21], ['Transactions', 'F', 'F', 34]
    ]) {
      const result = workbook.SetColWidth(sheet, start, end, width);
      if (result.error) throw new Error(result.error);
    }
    putRow('Dashboard', 'A1', ['EXPENSE TRACKER']);
    putRow('Dashboard', 'A2', [`Exported ${new Date().toLocaleString()}`]);
    putRow('Dashboard', 'A4', ['Total spent', rows.reduce((sum, row) => sum + Number(row.amount), 0)]);
    putRow('Dashboard', 'D4', ['Transactions', rows.length]);
    putRow('Dashboard', 'A6', ['Category', 'Amount']);

    const categoryTotals = new Map();
    for (const row of rows) categoryTotals.set(row.category, (categoryTotals.get(row.category) || 0) + Number(row.amount));
    const categories = [...categoryTotals.entries()].sort((a, b) => b[1] - a[1]);
    categories.forEach(([category, total], index) => putRow('Dashboard', `A${index + 7}`, [category, total]));

    putRow('Dashboard', 'D6', ['Month', 'Amount']);
    const current = new Date();
    const months = [];
    for (let offset = 5; offset >= 0; offset--) {
      const date = new Date(current.getFullYear(), current.getMonth() - offset, 1);
      const label = date.toLocaleDateString('en', { month: 'short', year: 'numeric' });
      const total = rows.reduce((sum, row) => {
        const spent = new Date(`${row.date}T00:00:00Z`);
        return spent.getUTCFullYear() === date.getFullYear() && spent.getUTCMonth() === date.getMonth()
          ? sum + Number(row.amount) : sum;
      }, 0);
      months.push([label, total]);
    }
    months.forEach((month, index) => putRow('Dashboard', `D${index + 7}`, month));

    putRow('Transactions', 'A1', ['Date', 'Description', 'Category', 'Amount', 'Payment method', 'Notes']);
    rows.forEach((row, index) => putRow('Transactions', `A${index + 2}`, [
      row.date, row.description, row.category, Number(row.amount), row.paymentMethod || 'Other', row.notes || ''
    ]));

    for (const [sheet, range, style] of [
      ['Dashboard', 'A1:A1', titleStyle.style],
      ['Dashboard', 'A6:B6', headerStyle.style], ['Dashboard', 'D6:E6', headerStyle.style],
      ['Transactions', 'A1:F1', headerStyle.style],
      ['Dashboard', 'B4:B4', moneyStyle.style]
    ]) {
      const result = workbook.SetCellStyle(sheet, range.split(':')[0], range.split(':')[1], style);
      if (result.error) throw new Error(result.error);
    }
    if (categories.length) {
      const result = workbook.SetCellStyle('Dashboard', 'B7', `B${categories.length + 6}`, moneyStyle.style);
      if (result.error) throw new Error(result.error);
    }
    const monthlyMoneyStyle = workbook.SetCellStyle('Dashboard', 'E7', 'E12', moneyStyle.style);
    if (monthlyMoneyStyle.error) throw new Error(monthlyMoneyStyle.error);
    if (rows.length) {
      const result = workbook.SetCellStyle('Transactions', 'D2', `D${rows.length + 1}`, moneyStyle.style);
      if (result.error) throw new Error(result.error);
    }

    if (categories.length) {
      const end = categories.length + 6;
      const chart = workbook.AddChart('Dashboard', 'A16', {
        Type: excelize.Bar,
        Series: [{ Name: 'Dashboard!$B$6', Categories: `Dashboard!$A$7:$A$${end}`, Values: `Dashboard!$B$7:$B$${end}` }],
        Title: { Paragraph: [{ Text: 'Spending by category' }] },
        Legend: { Position: 'none' }
      });
      if (chart.error) throw new Error(chart.error);
    }
    const trend = workbook.AddChart('Dashboard', 'G16', {
      Type: excelize.Line,
      Series: [{ Name: 'Dashboard!$E$6', Categories: 'Dashboard!$D$7:$D$12', Values: 'Dashboard!$E$7:$E$12' }],
      Title: { Paragraph: [{ Text: 'Monthly spending (last 6 months)' }] },
      Legend: { Position: 'none' }
    });
    if (trend.error) throw new Error(trend.error);

    const output = workbook.WriteToBuffer();
    if (output.error) throw new Error(output.error);
    res.set({
      'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': 'attachment; filename="expense-tracker.xlsx"',
      'Content-Length': output.buffer.length
    });
    res.send(Buffer.from(output.buffer));
  } catch (error) {
    console.error('Export Excel:', error.message);
    res.status(503).json({ error: 'Could not create the Excel export. Check the MySQL connection and try again.' });
  }
});

app.post('/api/expenses', async (req, res) => {
  const { date, description, category, amount, paymentMethod, notes } = req.body || {};
  const value = Number(amount);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(date || '')) || Number.isNaN(Date.parse(`${date}T00:00:00Z`)))
    return res.status(400).json({ error: 'Enter a valid expense date.' });
  if (typeof description !== 'string' || !description.trim() || description.trim().length > 180)
    return res.status(400).json({ error: 'Description is required (180 characters max).' });
  if (typeof category !== 'string' || !category.trim() || category.length > 40)
    return res.status(400).json({ error: 'Choose a category.' });
  if (!Number.isFinite(value) || value <= 0 || value > 9999999999.99)
    return res.status(400).json({ error: 'Amount must be greater than zero.' });
  const method = typeof paymentMethod === 'string' && paymentMethod.trim() ? paymentMethod.trim().slice(0,40) : 'Other';
  const memo = typeof notes === 'string' ? notes.trim().slice(0,500) : '';
  try {
    const [result] = await pool.execute(
      'INSERT INTO expenses (spent_on, description, category, amount, payment_method, notes) VALUES (?, ?, ?, ?, ?, ?)',
      [date, description.trim(), category.trim(), value, method, memo || null]
    );
    const [rows] = await pool.execute(
      'SELECT id, DATE_FORMAT(spent_on, "%Y-%m-%d") AS date, description, category, amount, payment_method AS paymentMethod, notes FROM expenses WHERE id = ?',
      [result.insertId]
    );
    res.status(201).json(rows[0]);
  } catch (error) {
    console.error('Save expense:', error.message);
    res.status(503).json({ error: 'Could not save expense. Check that MySQL is running and schema.sql has been applied.' });
  }
});

app.delete('/api/expenses/:id', async (req, res) => {
  if (!/^\d+$/.test(req.params.id)) return res.status(400).json({ error: 'Invalid expense id.' });
  try {
    const [result] = await pool.execute('DELETE FROM expenses WHERE id = ?', [req.params.id]);
    if (!result.affectedRows) return res.status(404).json({ error: 'Expense not found.' });
    res.status(204).end();
  } catch (error) {
    console.error('Delete expense:', error.message);
    res.status(503).json({ error: 'Could not delete expense.' });
  }
});

app.listen(port, () => console.log(`Expense Tracker running at http://localhost:${port}`));

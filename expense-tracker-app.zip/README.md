# Spendly — MySQL Expense Tracker

A local web expense tracker with a browser UI, a Node.js API, and MySQL as its database. Add expenses in the form; saved transactions immediately refresh the dashboard totals and charts. Use **Export to Excel** on the dashboard to download an `.xlsx` workbook containing the saved transactions and native Excel charts for category and monthly spending. Export again after adding expenses to get the latest data in Excel.

## Requirements

- Node.js 20 or later
- MySQL Server 8.0 or later, running locally (or a reachable MySQL server)

## Setup (Windows PowerShell)

1. Open PowerShell in this folder.
2. Install the app packages:

   ```powershell
   npm install
   ```

3. Copy the environment template and enter your MySQL password:

   ```powershell
   Copy-Item .env.example .env
   notepad .env
   ```

   Set `DB_USER` and `DB_PASSWORD` to a MySQL account that can create the `expense_tracker` database and tables. Change `PORT` if port 3000 is already in use.

4. Create the database table. In a MySQL command prompt, run:

   ```sql
   SOURCE C:/path/to/expense-tracker-app/schema.sql;
   ```

   Or import `schema.sql` using MySQL Workbench. The script creates the database and table if they do not already exist.

5. Start the web app:

   ```powershell
   npm start
   ```

6. Open [http://localhost:3000](http://localhost:3000) (or the port configured in `.env`).

## Project files

- `server.js` — web server and JSON API
- `public/` — browser interface, styles and interactive charts
- `schema.sql` — MySQL database and table definition
- `.env.example` — local connection settings template

The app never includes database credentials in the browser. The API validates input and uses parameterized MySQL queries. Transactions can be deleted from the recent-transactions list.
